import matplotlib.pyplot as plt
import xlwings as xw
import pandas as pd
import numpy as np


def main():
    plt.style.use('ggplot') 
    wb = xw.Book('test.xlsm')
    sheet = wb.sheets['Sheet1']
    
    # Number of rows
    n_rows = 10_000_000
    
    # Generate data
    dates = pd.date_range(start='2023-01-01', periods=n_rows, freq='T')  # One-minute intervals
    regions = np.random.choice(['North', 'South', 'East', 'West'], size=n_rows)
    products = np.random.choice(['Product A', 'Product B', 'Product C'], size=n_rows)
    sales = np.random.randint(50, 1000, size=n_rows)
    
    # Create DataFrame
    df = pd.DataFrame({
        'Date': dates,
        'Region': regions,
        'Product': products,
        'Sales': sales
    })


    def mean_sales_above_threshold(series, threshold=300):
        filtered_sales = series[series > threshold]
        if filtered_sales.empty:
            return np.nan
        else:
            return filtered_sales.mean()
    
    # Create pivot table with custom aggregation
    pivot_table = pd.pivot_table(
        df, 
        values='Sales', 
        index=['Region'], 
        columns=['Product'], 
        aggfunc=lambda x: mean_sales_above_threshold(x, 300)  # Using the custom function
    )

    sheet.clear()
    for shape in sheet.shapes:
        shape.delete()

    sheet.range("A1").value = pivot_table

    grouped =  df.groupby('Product')['Sales'].mean().reset_index()
    
     
    fig = plt.figure(figsize=(9, 6))
    plt.bar(grouped['Product'], grouped['Sales'])
    
    plt.ylim([524,525])
    # Set the labels and title
    plt.xlabel('Product')
    plt.ylabel('Average Sales')
    plt.title('Average Sales per Product')
    
    plt.savefig('graph.png')  # Save the graph as an image file
    
    # Create a new workbook or connect to an existing workbook
     
    
    # Add the graph to Excel
    sheet.pictures.add('graph.png', name='MyPlot', update=True, left=sheet.range('H1').left, top=sheet.range('H1').top)
    
    if len(sheet.charts):
        sheet.charts[0].delete()

    chart = sheet.charts.add(left=sheet.range('A7').left, top= sheet.range('A7').top)
    chart.set_source_data(sheet.range('A1:D5'))
    chart.chart_type = 'line'

if __name__ == "__main__":
    xw.Book("test.xlsm").set_mock_caller()
    main()
